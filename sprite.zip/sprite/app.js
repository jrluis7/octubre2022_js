'use strict'

let width_img = 822;
let height_img = 580;

let width_count = 0;
let height_count = 0;

const width = 105;
const COLUMNS = 14;
const ROWS = 10;

let nodoMain = document.querySelector( '#containerImg' );
let nodoMuneco = document.querySelector( '#muneco' );

let player_x,player_y = 0;
let step = 10;
let direccion = "T";

let elements = [];

function pinto(direccion){
    switch( direccion ){
        case 'T':    
            if(player_y>0){
                player_y -= step;  
            }
        break;
        case 'R':
            player_x += step;    
        break;
        case 'L': 
            player_x -= step;
        break;
        case 'D':  
            player_y += step;
        break;
    }
    checkPosition(player_x,player_y);
    nodoMain.style.backgroundPosition = (width_img  / 4) * width_count + "px "+ (height_img  / 4) * height_count + "px ";
    posicionaJugador( player_x,player_y )
}

function checkPosition(player_x,player_y){
    console.log( "p_x:",player_x,"_y" ,player_y)
    console.log( nodoMuneco.offsetHeight )
    let h = nodoMuneco.offsetHeight;
    let w = nodoMuneco.offsetWidth;

    
    
    let ladrillos = elements.filter( e => e.type === 'ladrillo' )
    console.log( ladrillos )
    let found = ladrillos.find( cadaLadrillo =>{
        if( player_x+ width > cadaLadrillo.x &&
            player_x < cadaLadrillo.x + width &&
            player_y+ width > cadaLadrillo.y &&
            player_y < cadaLadrillo.y + width
            ){
                return true;
        }
    } )
    console.log( found ) 
    return
}

// pinto();


crearTablero();

let ref_timer;

function mueve(){
    if( ref_timer){
        return;
    }

        ref_timer = setInterval( ()=>{
            width_count--;
            if(width_count< -3){
                width_count = 0;
            }
         
            
            pinto(direccion);
        
        
        },60 )
    
   
    

}
function crearTablero(){
    tablero.style.width = width * COLUMNS + "px";
    tablero.style.height = width * ROWS + "px";
    let jugadorPuesto = false;

    for(let i = 0 ;i <ROWS; i++){

        for( let n=0;n<COLUMNS; n++ ){
            let pos_x = n * width;
            let pos_y = i * width;
            let element = getLadrillo( pos_x,pos_y )
            elements.push ( {e:element,x:pos_x,y:pos_y, type:element.classList.contains('ladrillo')?'ladrillo':'empty'} );
            tablero.appendChild( element );
            if( element.classList.contains('empty') && !jugadorPuesto ){
                jugadorPuesto = true;
                player_x = pos_x;
                player_y = pos_y;
                posicionaJugador( pos_x,pos_y );
            }
            
        }
    }

    // tablero.appendChild( getLadrillo( 200,200 ) );
}

function getLadrillo(x,y){
    let random = Math.random();
    if( random>0.8 ){
        let nodoLadrillo = document.createElement( 'div' );
        nodoLadrillo.classList.add( 'ladrillo' );
        nodoLadrillo.style.top = y+"px";
        nodoLadrillo.style.left = x+"px";
        return nodoLadrillo;
    }else{
        let nodoEmpty = document.createElement( 'div' );
        nodoEmpty.classList.add( 'empty' );
        return nodoEmpty;
    }
}

function posicionaJugador(x,y){
    nodoMuneco.style.position = "absolute";
    nodoMuneco.style.top = y + "px";
    nodoMuneco.style.left = x + "px";
}

document.addEventListener( 'keydown', function( e ){
    console.log( e );
    switch( e.key ){
        case 'w':
            direccion = 'T';
            height_count = -3;
            
            mueve();

        break;
        case 'd':
            direccion = 'R';

            height_count = -2;
            

            mueve();

        break;
        case 'a':
            direccion = 'L';

            height_count = -1;
           

            mueve();

        break;
        case 's':
            direccion = 'D';

            height_count = 0;
            


            mueve();
        break;
    }

} );


document.addEventListener( 'keyup', function( e ){
    clearInterval(ref_timer);
    ref_timer = null;
    direccion = "";
} );