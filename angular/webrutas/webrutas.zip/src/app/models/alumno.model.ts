

// Un tipo de "Clase" que define el formato de un dato
export interface Alumno {
    nombre: string;
    apellidos: string;
    fecha: number;
    nota: number;
    dni?: string;
}
