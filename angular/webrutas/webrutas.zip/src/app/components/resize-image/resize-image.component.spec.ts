import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResizeImageComponent } from './resize-image.component';

describe('ResizeImageComponent', () => {
  let component: ResizeImageComponent;
  let fixture: ComponentFixture<ResizeImageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResizeImageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ResizeImageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
