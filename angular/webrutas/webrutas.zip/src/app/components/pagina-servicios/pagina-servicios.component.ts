import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-servicios',
  templateUrl: './pagina-servicios.component.html',
  styleUrls: ['./pagina-servicios.component.scss']
})
export class PaginaServiciosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
