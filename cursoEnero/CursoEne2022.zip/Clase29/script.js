// TO DO LIST

// Guardar las tareas en LOCAL STORAGE

// ESTADO
let tareas = [ 
    { texto:"Hacer la compra",estado:"DONE" },
    { texto:"",estado:"PENDING" },
    { texto:"Hacer la compra",estado:"DONE" },
    { texto:"",estado:"" },
    { texto:"",estado:"" },
    { texto:"",estado:"" },
] ;

let tareas = {
    to_do:[ 

    ],
    done:[

    ]
 }  ;

let lista_todo = [];
let lista_done = [];

/*
AÑADIR TAREA =>{
    
    Coger valores de la entrada
    Crear objeto tarea
    Añadirlo a tareas por hacer  ( )
    Guardar LStorage
    Pintarla en la zona de por hacer
        - ....
}

COMPLETAR TAREA =>{

    Completar tarea ->
        { 
            Cambiar el estado de la tarea
            Eliminar de por hacer, añadir en completadas
        }
    Pintar en completadas( Borrar/Crear - Mover  )
    Guardar  LStorage


}


ELIMINAR TAREA =>{
    Elimino la tarea del array ( del que esté )
    Borro el div
    Guardar LStorage

}





*/
















