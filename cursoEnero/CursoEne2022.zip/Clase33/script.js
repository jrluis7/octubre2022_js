// Hacer LOGIN

// El back comprueba mi usuario y contraseña

// Me dan un TOKEN temporal




// KEY de desarrollador. Debería estar en el lado de servidor.
const KEY = "9f2dec9d-e89f-48f0-82e4-19c975582a74"
let id_gato = "";

fetch( 'https://api.thecatapi.com/v1/images/search' ).then( respuesta=>{
    return respuesta.json();
} ).then( datos =>{

    console.log( datos )
    console.log( datos[0].url )
    id_gato = datos[0].id
    imagenGato.src = datos[0].url


} ).catch( err=>{
    console.log( err )
} )



// fetch( 'https://api.thecatapi.com/v1/favourites?api_key='+KEY ).then( respuesta=>{
//     return respuesta.json();
// } ).then( datos =>{

//     console.log( datos )


// } ).catch( err=>{
//     console.log( err )
// } )


fetch( 'https://api.thecatapi.com/v1/favourites' ,{
    method:"GET",
    headers:{
        'Content-Type':'application/json',
        // 'Authorization': 'Bearer 4a8s1d8a4s17th678ssd7e57y5a7s5'
        'x-api-key':KEY
    }
} )
.then(respuesta=> respuesta.json() )
.then( datos=>{
    console.log( datos );
} )

let nodoFav = document.querySelector( '#btnFav' );

nodoFav.addEventListener( 'click', function(){

    let data = {
        image_id:id_gato
    }

    fetch( 'https://api.thecatapi.com/v1/favourites',{
        method: 'POST',
        body: JSON.stringify(data),
        headers:{
            'Content-Type':'application/json',
            'x-api-key':KEY
        }
    } )
    .then(respuesta=> respuesta.json() )
    .then( datos=>{
        console.log( datos );
    } ).catch( error=>{
        console.log( error )
    } );

} )


