import {Juego} from './script.js';



var juego = new Juego();

console.log( juego );






