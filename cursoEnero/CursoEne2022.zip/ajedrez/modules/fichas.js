export const BLANCAS = "BLANCAS";
export const NEGRAS = "NEGRAS";
