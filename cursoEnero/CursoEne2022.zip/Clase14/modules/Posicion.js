export class Posicion{
    x;y;
    constructor( x, y ){
        this.x = x;
        this.y = y;
    }

}