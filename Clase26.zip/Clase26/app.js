'use strict'


// 27-28 jQuery
// Métodos de STRING Avanzados
// Espresiones regulares / Formularios
// AJAX y APIS
// Asíncronía y Promesas
// Local Storage
// Métodos de Listas, filter, reduce, map

// 35-40 -> Proyecto 

// 40-50 Angular / React




let diff = 12343; // mseg;

let cent = diff / 10; //1234,3centesimas  -> Sólo con los 

console.log('Cetésimas', cent % 100);
console.log('Segundos', (cent / 100) % 60);